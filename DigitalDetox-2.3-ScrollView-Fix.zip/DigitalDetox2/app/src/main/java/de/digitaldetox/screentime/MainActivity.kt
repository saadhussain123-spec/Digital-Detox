package de.digitaldetox.screentime

import android.app.*
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val apps = listOf(
        TrackedApp("YouTube", "com.google.android.youtube", "▶", Color.rgb(244, 54, 54)),
        TrackedApp("TikTok", "com.zhiliaoapp.musically", "♪", Color.rgb(20, 23, 30)),
        TrackedApp("Instagram", "com.instagram.android", "◎", Color.rgb(190, 72, 160)),
        TrackedApp("Facebook", "com.facebook.katana", "f", Color.rgb(45, 116, 235))
    )
    private val prefs by lazy { getSharedPreferences("digital_detox_v2", MODE_PRIVATE) }
    private val bg = Color.rgb(8, 16, 29)
    private val panel = Color.rgb(18, 31, 49)
    private val panel2 = Color.rgb(23, 40, 60)
    private val green = Color.rgb(61, 220, 139)
    private val blue = Color.rgb(75, 174, 255)
    private val muted = Color.rgb(159, 177, 197)
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private var selectedTab = 0
    private var lastTotals = LongArray(4)

    data class TrackedApp(val name: String, val pkg: String, val glyph: String, val color: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        createChannel()
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) render()
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        else @Suppress("DEPRECATION") ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun dayStart(offset: Int = 0): Long {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_YEAR, offset)
        }
        return c.timeInMillis
    }

    private fun usage(pkg: String, start: Long, end: Long): Long {
        val mgr = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = mgr.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end) ?: return 0L
        return stats.filter { it.packageName == pkg && it.lastTimeUsed >= start }
            .sumOf { it.totalTimeInForeground }.coerceAtLeast(0L)
    }

    private fun todayTotals(): LongArray = LongArray(apps.size) { i ->
        usage(apps[i].pkg, dayStart(), System.currentTimeMillis())
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val scroll = ScrollView(this).apply { setFillViewport(true) }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(18))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomNav(), LinearLayout.LayoutParams(-1, dp(68)))
        setContentView(root)

        when (selectedTab) {
            0 -> dashboard()
            1 -> statistics()
            2 -> goals()
            else -> about()
        }
    }

    private fun dashboard() {
        header("Digital Detox", "Weniger Bildschirm. Mehr Leben.")
        if (!hasUsageAccess()) {
            card {
                title("Willkommen bei Digital Detox")
                bodyText("Erlaube den Nutzungszugriff, damit deine Bildschirmzeit für YouTube, TikTok, Instagram und Facebook automatisch gemessen werden kann.")
                actionButton("Nutzungszugriff aktivieren", green) {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
            }
            return
        }
        val totals = todayTotals()
        lastTotals = totals
        val total = totals.sum()
        val limit = prefs.getLong("limit_total", 3L * 60 * 60 * 1000)
        card {
            row {
                column(1f) {
                    smallLabel("DEINE BILDSCHIRMZEIT HEUTE")
                    bigValue(format(total), Color.WHITE)
                    bodyText("Tagesziel: ${format(limit)}")
                }
                addView(ProgressRing(this@MainActivity, total.toFloat(), max(1L, limit).toFloat(), green), LinearLayout.LayoutParams(dp(92), dp(92)))
            }
            val percent = (total * 100 / max(1L, limit)).coerceAtMost(100)
            addView(ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; progress = percent.toInt()
                progressTintList = android.content.res.ColorStateList.valueOf(green)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(43, 58, 75))
            }, LinearLayout.LayoutParams(-1, dp(7)).apply { topMargin = dp(14) })
            smallLabel(if (total <= limit) "$percent % deines Tageslimits verwendet" else "Tageslimit überschritten")
        }
        sectionTitle("Deine Apps", "HEUTE")
        apps.forEachIndexed { i, app ->
            appCard(app, totals[i], prefs.getLong("limit_${app.pkg}", 60L * 60L * 1000))
        }
        card {
            row {
                column(1f) {
                    title("Dein Fortschritt")
                    bodyText("Behalte deine Gewohnheiten im Blick und setze dir erreichbare Ziele.")
                }
                text("↗", 28, green, true)
            }
            actionButton("Statistiken ansehen", blue) { selectedTab = 1; render() }
        }
        footer()
    }

    private fun statistics() {
        header("Deine Statistiken", "Erkenne deine digitalen Gewohnheiten")
        if (!hasUsageAccess()) { permissionCard(); return }
        val today = todayTotals()
        val week = LongArray(7) { day ->
            apps.sumOf { usage(it.pkg, dayStart(-day), minOf(dayStart(-day + 1), System.currentTimeMillis())) }
        }
        card {
            smallLabel("GESAMT HEUTE")
            bigValue(format(today.sum()), green)
            bodyText("Überwachte Apps: YouTube, TikTok, Instagram und Facebook")
        }
        sectionTitle("Letzte 7 Tage", "NUTZUNGSZEIT")
        card {
            addView(BarChart(this@MainActivity, week.reversedArray(), blue), LinearLayout.LayoutParams(-1, dp(190)))
            row {
                smallLabel("Wochensumme")
                text(format(week.sum()), 16, Color.WHITE, true)
            }
            row {
                smallLabel("Tagesdurchschnitt")
                text(format(week.sum() / 7), 16, green, true)
            }
        }
        sectionTitle("Heute nach App", "RANKING")
        apps.sortedByDescending { app -> today[apps.indexOf(app)] }.forEach { app ->
            val value = today[apps.indexOf(app)]
            appCard(app, value, prefs.getLong("limit_${app.pkg}", 60L * 60L * 1000))
        }
        footer()
    }

    private fun goals() {
        header("Deine Ziele", "Setze bewusste Grenzen")
        if (!hasUsageAccess()) permissionCard()
        card {
            title("Gesamtes Tageslimit")
            bodyText("Lege fest, wie lange du alle vier Apps zusammen täglich nutzen möchtest.")
            val current = prefs.getLong("limit_total", 3L * 60 * 60 * 1000)
            text(format(current), 24, green, true)
            actionButton("Gesamtlimit ändern", blue) { editLimit("limit_total", current, "Gesamtes Tageslimit") }
        }
        sectionTitle("Individuelle Limits", "PRO APP")
        apps.forEach { app ->
            val key = "limit_${app.pkg}"
            val value = prefs.getLong(key, 60L * 60L * 1000)
            card {
                row {
                    appIcon(app)
                    column(1f) {
                        title(app.name)
                        bodyText("Limit: ${format(value)}")
                    }
                    text("›", 28, muted, true)
                }
                actionButton("Limit einstellen", panel2) { editLimit(key, value, "${app.name}-Limit") }
            }
        }
        footer()
    }

    private fun about() {
        header("Über die App", "Digital Detox – Screen Time")
        card {
            text("◷", 42, green, true)
            title("Digital Detox")
            bodyText("Eine einfache Hilfe, um deine Bildschirmzeit bewusster zu gestalten.")
            bodyText("Überwacht werden YouTube (inklusive Shorts), TikTok, Instagram und Facebook.")
        }
        card {
            title("Entwickler")
            bigValue("Dr. Saad Hussain", Color.WHITE)
            bodyText("Entwickelt und erstellt von Dr. Saad Hussain.")
        }
        card {
            title("Datenschutz")
            bodyText("Die Nutzungsstatistiken werden auf deinem Gerät ausgelesen und lokal verarbeitet. Es gibt kein Benutzerkonto und keine Cloud-Synchronisierung.")
            bodyText("Android kann YouTube Shorts nicht getrennt von anderen YouTube-Inhalten erfassen.")
        }
        footer()
    }

    private fun appCard(app: TrackedApp, value: Long, limit: Long) {
        card {
            row {
                appIcon(app)
                column(1f) {
                    title(app.name)
                    bodyText(if (app.name == "YouTube") "Videos und Shorts" else "Nutzungszeit heute")
                }
                text(format(value), 17, Color.WHITE, true)
            }
            val pct = (value * 100 / max(1L, limit)).coerceAtMost(100).toInt()
            addView(ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; progress = pct
                progressTintList = android.content.res.ColorStateList.valueOf(app.color)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(43, 58, 75))
            }, LinearLayout.LayoutParams(-1, dp(6)).apply { topMargin = dp(12) })
            smallLabel("$pct % des App-Limits")
        }
    }

    private fun permissionCard() {
        card {
            title("Nutzungszugriff erforderlich")
            bodyText("Aktiviere den Nutzungszugriff in den Android-Einstellungen und kehre dann hierher zurück.")
            actionButton("Einstellungen öffnen", green) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
    }

    private fun header(title: String, subtitle: String) {
        body.row {
            column(1f) {
                text(title, 27, Color.WHITE, true)
                bodyText(subtitle)
            }
            text("◷", 30, green, true)
        }
        body.addSpace(16)
    }

    private fun sectionTitle(text: String, label: String) {
        body.row {
            text(text, 19, Color.WHITE, true)
            text(label, 10, muted, true)
        }
        body.addSpace(8)
    }

    private fun card(block: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(panel, 20)
        }
        box.block()
        body.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun LinearLayout.row(block: LinearLayout.() -> Unit) {
        val r = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        r.block()
        addView(r, LinearLayout.LayoutParams(-1, -2))
    }

    private fun LinearLayout.column(weight: Float, block: LinearLayout.() -> Unit) {
        val c = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
        c.block()
        addView(c, LinearLayout.LayoutParams(0, -2, weight))
    }

    private fun LinearLayout.appIcon(app: TrackedApp) {
        val icon = TextView(this@MainActivity).apply {
            text = app.glyph; textSize = 25f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD
            background = rounded(app.color, 15)
        }
        addView(icon, LinearLayout.LayoutParams(dp(52), dp(52)).apply { rightMargin = dp(13) })
    }

    private fun LinearLayout.title(value: String) = text(value, 17, Color.WHITE, true)
    private fun LinearLayout.bodyText(value: String) = text(value, 13, muted, false)
    private fun LinearLayout.smallLabel(value: String) = text(value, 11, muted, true)
    private fun LinearLayout.bigValue(value: String, color: Int) = text(value, 30, color, true)

    private fun LinearLayout.text(value: String, size: Int, color: Int, bold: Boolean) {
        addView(TextView(this@MainActivity).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            if (bold) typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(3))
        }, LinearLayout.LayoutParams(-2, -2))
    }

    private fun LinearLayout.actionButton(label: String, color: Int, action: () -> Unit) {
        val b = TextView(this@MainActivity).apply {
            text = label; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(if (color == green) bg else Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(dp(15), dp(12), dp(15), dp(12))
            background = rounded(color, 14)
            setOnClickListener { action() }
        }
        addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
    }

    private fun LinearLayout.addSpace(h: Int) { addView(View(this@MainActivity), LinearLayout.LayoutParams(1, dp(h))) }

    private fun bottomNav(): View {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(5), dp(5), dp(5))
            setBackgroundColor(Color.rgb(13, 25, 40))
        }
        val labels = listOf("⌂\nHome", "▥\nStatistik", "◎\nZiele", "ⓘ\nÜber")
        labels.forEachIndexed { i, label ->
            val item = TextView(this).apply {
                text = label; gravity = Gravity.CENTER; textSize = 12f
                setTextColor(if (selectedTab == i) green else muted)
                typeface = if (selectedTab == i) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
                setOnClickListener { selectedTab = i; render() }
            }
            nav.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
        }
        return nav
    }

    private fun editLimit(key: String, current: Long, label: String) {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText((current / 3600000L).toString())
            hint = "Stunden (1–24)"
        }
        AlertDialog.Builder(this).setTitle(label).setMessage("Limit in Stunden")
            .setView(input)
            .setPositiveButton("Speichern") { _, _ ->
                val h = input.text.toString().toIntOrNull()
                if (h != null && h in 1..24) {
                    prefs.edit().putLong(key, h * 3600000L).apply()
                    render()
                } else Toast.makeText(this, "Bitte 1 bis 24 Stunden eingeben.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Abbrechen", null).show()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("limit", "Zeitlimit", NotificationManager.IMPORTANCE_DEFAULT)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun footer() {
        body.addSpace(12)
        body.text("Entwickelt von Dr. Saad Hussain", 12, muted, false)
        body.text("Digital Detox · Version 2.0", 10, muted, false)
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun format(ms: Long): String {
        val min = ms.coerceAtLeast(0) / 60000
        return if (min / 60 > 0) "${min / 60} Std. ${min % 60} Min." else "${min} Min."
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    inner class ProgressRing(ctx: Context, private val value: Float, private val maxValue: Float, private val color: Int) : View(ctx) {
        private val p = Paint(3)
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val h = height.toFloat()
            val rect = RectF(8f, 8f, w - 8f, h - 8f)
            p.style = Paint.Style.STROKE; p.strokeWidth = 9f; p.strokeCap = Paint.Cap.ROUND
            p.color = Color.rgb(43, 58, 75); c.drawArc(rect, -90f, 360f, false, p)
            p.color = color; c.drawArc(rect, -90f, 360f * (value / maxValue).coerceIn(0f, 1f), false, p)
            p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = 25f; p.typeface = Typeface.DEFAULT_BOLD; p.color = Color.WHITE
            c.drawText("${(value * 100 / maxValue).toInt().coerceAtMost(999)}%", w / 2, h / 2 + 8, p)
        }
    }

    inner class BarChart(ctx: Context, private val values: LongArray, private val color: Int) : View(ctx) {
        private val p = Paint(3)
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val maxV = max(1L, values.maxOrNull() ?: 1L).toFloat()
            val left = 8f; val bottom = height - 28f; val top = 12f
            val gap = 13f
            val barW = (width - left * 2 - gap * (values.size - 1)) / values.size
            for (i in values.indices) {
                val h = (bottom - top) * (values[i] / maxV)
                p.color = Color.rgb(43, 58, 75); p.strokeWidth = 1f
                c.drawLine(left, bottom, width - left, bottom, p)
                p.color = color
                val r = RectF(left + i * (barW + gap), bottom - h, left + i * (barW + gap) + barW, bottom)
                c.drawRoundRect(r, 9f, 9f, p)
                p.color = muted; p.textSize = 10f; p.textAlign = Paint.Align.CENTER
                val label = listOf("Mo","Di","Mi","Do","Fr","Sa","So")[i]
                c.drawText(label, r.centerX(), height - 7f, p)
            }
        }
    }
}
