# Digital Detox 2.0

Native Android app for local screen-time monitoring of YouTube (including Shorts), TikTok, Instagram and Facebook.

## Build
Use GitHub Actions: Actions → Build Digital Detox APK → Run workflow.
The workflow uses Java 17, Android SDK setup v4 and Gradle 8.9.
Download `DigitalDetox-v2-debug-apk` from the successful workflow artifact.

## First launch
Open the app and grant Usage Access under Android Settings → Special app access → Usage access.

## Notes
- Usage is based on Android UsageStats and may be delayed by the OS.
- YouTube Shorts cannot be separated from other YouTube app usage using this API.
- Per-app and combined daily limits are configurable. This build displays the current usage and goal progress; it does not continuously block apps or guarantee background alerts.
- No account, cloud sync or network permission is included. Usage is processed locally.
- Developed by Dr. Saad Hussain.
