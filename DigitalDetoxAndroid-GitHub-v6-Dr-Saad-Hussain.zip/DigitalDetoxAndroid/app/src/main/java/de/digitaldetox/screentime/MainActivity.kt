package de.digitaldetox.screentime

import android.app.Activity
import android.app.AppOpsManager
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val youtube = "com.google.android.youtube"
    private val tiktok = "com.zhiliaoapp.musically"
    private val instagram = "com.instagram.android"
    private val facebook = "com.facebook.katana"
    private val prefs by lazy { getSharedPreferences("digital_detox", Context.MODE_PRIVATE) }
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        showDashboard()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) showDashboard()
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun showDashboard() {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 40)
            setBackgroundColor(Color.rgb(12, 18, 32))
        }
        scroll.addView(content)
        setContentView(scroll)

        addText("DIGITAL DETOX", 14, Color.rgb(105, 190, 255), true)
        addText("Deine Bildschirmzeit", 29, Color.WHITE, true)
        addText("YouTube inkl. Shorts · TikTok · Instagram · Facebook", 14, Color.LTGRAY, false)
        addGap(22)

        if (!hasUsageAccess()) {
            addText("Noch kein Nutzungszugriff", 21, Color.WHITE, true)
            addText("Android muss der App erlauben, die Nutzungszeit anderer Apps auszulesen. Deine Daten werden nur lokal auf diesem Gerät verarbeitet.", 15, Color.LTGRAY, false)
            addGap(12)
            addButton("Nutzungszugriff aktivieren") {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
            addGap(12)
            addText("Aktiviere dort „Digital Detox“ und kehre anschließend hierher zurück.", 13, Color.LTGRAY, false)
            addGap(24)
            addAboutSection()
            return
        }

        val today = dayRange(0)
        val ytToday = usageFor(youtube, today.first, today.second)
        val ttToday = usageFor(tiktok, today.first, today.second)
        val igToday = usageFor(instagram, today.first, today.second)
        val fbToday = usageFor(facebook, today.first, today.second)
        val total = ytToday + ttToday + igToday + fbToday
        val limit = prefs.getLong("daily_limit", 3L * 60L * 60L * 1000L)

        addPanel("HEUTE GESAMT", formatDuration(total), "Tageslimit: ${formatDuration(limit)}")
        addGap(12)
        addPanel("▶  YOUTUBE + SHORTS", formatDuration(ytToday), "Gesamte YouTube-App-Nutzung")
        addGap(12)
        addPanel("♪  TIKTOK", formatDuration(ttToday), "Nutzung der TikTok-App")
        addGap(12)
        addPanel("◎  INSTAGRAM", formatDuration(igToday), "Nutzung der Instagram-App")
        addGap(12)
        addPanel("f  FACEBOOK", formatDuration(fbToday), "Nutzung der Facebook-App")
        addGap(20)

        addText("Letzte 7 Tage", 21, Color.WHITE, true)
        var weekTotal = 0L
        for (i in 6 downTo 0) {
            val range = dayRange(i)
            val value = usageFor(youtube, range.first, range.second) +
                    usageFor(tiktok, range.first, range.second) +
                    usageFor(instagram, range.first, range.second) +
                    usageFor(facebook, range.first, range.second)
            weekTotal += value
            val cal = Calendar.getInstance().apply { timeInMillis = range.first }
            val label = SimpleDateFormat("EEE, dd.MM", Locale.GERMANY).format(cal.time)
            addText("$label     ${formatDuration(value)}", 15, Color.LTGRAY, false)
        }
        addGap(8)
        addPanel("WOCHENSUMME", formatDuration(weekTotal), "Durchschnitt: ${formatDuration(weekTotal / 7)} pro Tag")
        addGap(18)

        val monthStart = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val monthEnd = System.currentTimeMillis()
        val monthTotal = usageFor(youtube, monthStart, monthEnd) +
                usageFor(tiktok, monthStart, monthEnd) +
                usageFor(instagram, monthStart, monthEnd) +
                usageFor(facebook, monthStart, monthEnd)
        addPanel("DIESER MONAT", formatDuration(monthTotal), "Seit Monatsbeginn")
        addGap(20)

        addButton("Tageslimit ändern") { editLimit(limit) }
        addGap(8)
        addButton("Aktualisieren") { showDashboard() }
        addGap(12)
        addText("Hinweis: Android aktualisiert Nutzungsstatistiken teilweise verzögert. Die Werte werden beim Öffnen bzw. Aktualisieren der App neu abgefragt. YouTube Shorts lassen sich über diese Android-Schnittstelle nicht getrennt von normalen YouTube-Videos messen.", 13, Color.LTGRAY, false)
        addGap(18)
        addAboutSection()
        if (total >= limit && total > 0) notifyLimit(total, limit)
    }


    private fun addAboutSection() {
        val divider = View(this).apply { setBackgroundColor(Color.rgb(55, 68, 88)) }
        content.addView(divider, LinearLayout.LayoutParams(-1, 1))
        addGap(10)
        addButton("Über die App") {
            AlertDialog.Builder(this)
                .setTitle("Digital Detox")
                .setMessage("Digital Detox – Screen Time\\n\\nEntwickelt und erstellt von Dr. Saad Hussain.\\n\\nDie App hilft dabei, die Nutzungszeit von YouTube (inklusive Shorts), TikTok, Instagram und Facebook im Blick zu behalten. Die Nutzungsdaten werden lokal auf diesem Gerät verarbeitet.")
                .setPositiveButton("Schließen", null)
                .show()
        }
        addText("Entwickelt von Dr. Saad Hussain", 13, Color.LTGRAY, false)
    }

    private fun usageFor(packageName: String, start: Long, end: Long): Long {
        val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats: List<UsageStats> = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end) ?: emptyList()
        return stats.filter { it.packageName == packageName && it.lastTimeUsed >= start }
            .sumOf { it.totalTimeInForeground }
    }

    private fun dayRange(daysAgo: Int): Pair<Long, Long> {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_YEAR, -daysAgo)
        }
        val start = c.timeInMillis
        c.add(Calendar.DAY_OF_YEAR, 1)
        return Pair(start, minOf(c.timeInMillis, System.currentTimeMillis()))
    }

    private fun editLimit(current: Long) {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(((current / 60000L) / 60L).toString())
            hint = "Stunden pro Tag"
        }
        AlertDialog.Builder(this)
            .setTitle("Tageslimit in Stunden")
            .setView(input)
            .setPositiveButton("Speichern") { _, _ ->
                val hours = input.text.toString().toLongOrNull()
                if (hours != null && hours in 1..24) {
                    prefs.edit().putLong("daily_limit", hours * 60L * 60L * 1000L).apply()
                    showDashboard()
                } else Toast.makeText(this, "Bitte 1 bis 24 Stunden eingeben.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun notifyLimit(total: Long, limit: Long) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val intent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            android.app.Notification.Builder(this, "limit")
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(this)
        }.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Digital Detox: Tageslimit erreicht")
            .setContentText("Du hast ${formatDuration(total)} in den überwachten Apps genutzt (Limit: ${formatDuration(limit)}).")
            .setContentIntent(intent).setAutoCancel(true).build()
        nm.notify(1001, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("limit", "Zeitlimit-Warnungen", NotificationManager.IMPORTANCE_DEFAULT)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun addText(text: String, size: Int, color: Int, bold: Boolean) {
        content.addView(TextView(this).apply {
            this.text = text; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        })
    }

    private fun addPanel(title: String, value: String, subtitle: String) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            setBackgroundColor(Color.rgb(27, 38, 59))
        }
        panel.addView(TextView(this).apply { text = title; textSize = 13f; setTextColor(Color.LTGRAY) })
        panel.addView(TextView(this).apply {
            text = value; textSize = 28f; setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 8, 0, 5)
        })
        panel.addView(TextView(this).apply { text = subtitle; textSize = 13f; setTextColor(Color.LTGRAY) })
        content.addView(panel, LinearLayout.LayoutParams(-1, -2))
    }

    private fun addButton(label: String, action: () -> Unit) {
        content.addView(Button(this).apply {
            text = label; setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun addGap(height: Int) {
        content.addView(View(this), LinearLayout.LayoutParams(1, height))
    }

    private fun formatDuration(ms: Long): String {
        val minutes = (ms.coerceAtLeast(0) / 60000L)
        val hours = minutes / 60
        val mins = minutes % 60
        return if (hours > 0) "$hours Std. $mins Min." else "$mins Min."
    }
}
