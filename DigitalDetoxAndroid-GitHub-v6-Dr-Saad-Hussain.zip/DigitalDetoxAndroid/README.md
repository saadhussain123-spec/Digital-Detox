# Digital Detox – Android

Native Android app for local foreground-usage reporting of YouTube, TikTok, Instagram and Facebook.

## Build APK with GitHub Actions

1. Create a new GitHub repository.
2. Upload the complete contents of this project (including the hidden `.github` folder).
3. Push to the `main` branch, or open **Actions → Build Android APK → Run workflow**.
4. Open the successful workflow run and download the artifact named `DigitalDetox-debug-apk`.
5. Extract the ZIP artifact and install `app-debug.apk` on your Android phone.

The workflow uses Java 17, Android SDK setup v4 and Gradle 8.9. It builds a debug APK.

## First launch

Open Digital Detox, tap **Nutzungszugriff aktivieren**, enable Digital Detox under Android's Usage access settings, then return to the app.

On Android 13 and newer, notifications may also require notification permission. This first version displays limit notifications when the app is opened/refreshed after the limit is reached.

## Measurement limitations

- YouTube time includes Shorts and all other YouTube app activity; Android's Usage Stats API cannot reliably separate Shorts from regular videos.
- TikTok, Instagram and Facebook are measured as total foreground time in their respective apps.
- Android may update usage statistics with a delay.
- The app reads aggregate foreground duration for the two selected package IDs. It does not inspect watched videos, searches, messages, or content.
- All processing and preferences stay locally on the device. No account, network access, or cloud sync is included.
- The app refreshes when opened or manually refreshed; it does not promise continuous background alerts.


## Credits

Digital Detox – Screen Time  
Developed and created by **Dr. Saad Hussain**.
